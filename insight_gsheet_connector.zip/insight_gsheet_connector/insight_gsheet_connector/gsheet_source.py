import io, logging
from typing import List, Dict, Any

import pandas as pd
import requests

try:
    from insights.data_source import BaseDataSource
except Exception:
    try:
        from frappe_insights.insights.data_source import BaseDataSource
    except Exception:
        class BaseDataSource:
            data_source_type = "Base"
            def __init__(self, data_source):
                self.data_source = data_source
            def get_tables(self): return []
            def get_columns(self, table): return []
            def execute_query(self, query): return []

logger = logging.getLogger(__name__)

class GoogleSheetDataSource(BaseDataSource):
    """Adapter for Google Sheets (CSV export)."""
    data_source_type = "Google Sheet"
    label = "Google Sheet"

    def __init__(self, data_source: Dict[str, Any]):
        super().__init__(data_source)
        self.data_source = data_source
        self._cache = None
        self._cache_ts = None
        # resolve if data_source is a docname (Frappe doctype record)
        try:
            import frappe
            if isinstance(self.data_source, str):
                try:
                    doc = frappe.get_doc('Insight Google Sheet Source', self.data_source)
                    self.data_source = doc
                except Exception:
                    pass
        except Exception:
            pass

    def get_tables(self) -> List[Dict[str, str]]:
        tab = self._get_config("tab")
        if tab:
            return [{"label": tab, "value": tab}]
        return [{"label": "Sheet", "value": "Sheet"}]

    def get_columns(self, table: str) -> List[Dict[str, str]]:
        df = self._load_sheet()
        return [{"label": c, "value": c} for c in df.columns]

    def execute_query(self, query: str) -> List[Dict[str, Any]]:
        df = self._load_sheet()
        q = (query or "").strip()
        if not q:
            return df.to_dict("records")
        if q.lower().startswith("select"):
            try:
                body = q[6:].strip()
                cols_part = body.split("from")[0]
                cols = [c.strip() for c in cols_part.split(",")]
                cols = [c for c in cols if c in df.columns]
                if cols:
                    return df[cols].to_dict("records")
            except Exception:
                pass
        return df.to_dict("records")

    def _get_config(self, key: str, default=None):
        if isinstance(self.data_source, dict):
            return self.data_source.get(key, default)
        try:
            return getattr(self.data_source, key, default)
        except Exception:
            return default

    def _load_sheet(self) -> pd.DataFrame:
        import time
        cache_seconds = int(self._get_config("cache_seconds", 30))
        now = time.time()
        if self._cache is not None and (now - (self._cache_ts or 0)) < cache_seconds:
            return self._cache.copy()

        url = self._get_config("url") or ""
        if not url:
            raise ValueError("Google Sheet data source requires a 'url' configuration")

        csv_url = self._to_csv_url(url)
        logger.debug("Fetching sheet CSV from: %s", csv_url)

        resp = requests.get(csv_url, timeout=30)
        resp.raise_for_status()

        text = resp.content.decode("utf-8")
        df = pd.read_csv(io.StringIO(text))

        header = self._get_config("header", True)
        if not header and df.shape[0] > 0:
            df.columns = [f"col_{i}" for i in range(len(df.columns))]

        self._cache = df.copy()
        self._cache_ts = now
        return df

    def _to_csv_url(self, url: str) -> str:
        if "export?format=csv" in url:
            return url
        import re
        m = re.search(r"/d/([a-zA-Z0-9-_]+)", url)
        spreadsheet_id = m.group(1) if m else None
        gid_match = re.search(r"[gG]id=(\d+)", url)
        gid = gid_match.group(1) if gid_match else self._get_config("gid")
        if spreadsheet_id:
            out = f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}/export?format=csv"
            if gid:
                out += f"&gid={gid}"
            return out
        return url