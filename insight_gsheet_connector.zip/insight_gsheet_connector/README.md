# insight_gsheet_connector

Small Frappe app that registers a Google Sheet Data Source type for Frappe Insights.

## Install

1. Put the zip or app folder into your bench environment.
2. Install dependencies: `pip install -r requirements.txt` (inside a virtualenv used by bench).
3. From bench root:
   - `bench get-app /path/to/insight_gsheet_connector.zip`  (or copy folder to apps/)
   - `bench --site yoursite install-app insight_gsheet_connector`
   - `bench restart`
4. In Frappe UI go to Insights → Data Sources → Add New → choose "Google Sheet".

## Config

When creating the Data Source, set fields:
- url: Google Sheets public export URL or standard url
- gid (optional): sheet gid
- tab (optional): tab name
- cache_seconds (optional): integer seconds to cache fetched CSV

Note: For private sheets, extend `_load_sheet` to use Google API + OAuth2.