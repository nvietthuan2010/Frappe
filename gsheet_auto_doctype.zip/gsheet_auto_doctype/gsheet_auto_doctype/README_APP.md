Additional notes:
- This app assumes the 'SpreadSheet' DocType exists (from your current Google Sheets integration app).
- For private sheets: extend the requests.get calls to use OAuth/service account.
- The scheduler will run every 30 minutes (cron entry in hooks.py).
