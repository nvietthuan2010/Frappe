import frappe
import csv
import requests
from io import StringIO

@frappe.whitelist()
def create_doctype_from_sheet(sheet_url: str, sheet_name: str = None):
    if not sheet_url:
        frappe.throw("sheet_url is required")

    if not sheet_name:
        sheet_name = "GSHEET_" + frappe.generate_hash(length=6)

    docname = frappe.scrub(sheet_name).replace("_", " ").title().replace(" ", "_")

    if frappe.db.exists("DocType", docname):
        return docname

    # convert edit URL to export CSV if possible
    csv_url = sheet_url
    if "/edit#gid=" in csv_url:
        csv_url = csv_url.replace("/edit#gid=", "/export?format=csv&gid=")
    elif csv_url.endswith("/edit"):
        csv_url = csv_url.replace("/edit", "/export?format=csv")

    try:
        res = requests.get(csv_url, timeout=20)
        res.raise_for_status()
    except Exception as e:
        frappe.throw(f"Error fetching sheet CSV: {e}")

    try:
        sio = StringIO(res.text)
        reader = csv.reader(sio)
        headers = next(reader, [])
    except Exception as e:
        frappe.throw(f"Error parsing CSV header: {e}")

    if not headers:
        frappe.throw("No header row found in the sheet")

    new_doctype = frappe.new_doc("DocType")
    new_doctype.name = docname
    new_doctype.module = "Custom"
    new_doctype.custom = 1
    new_doctype.autoname = 'field:name' if 'name' in [h.lower() for h in headers] else 'hash'
    new_doctype.document_type = 'List'

    for h in headers:
        label = h.strip()
        if not label:
            continue
        fieldname = frappe.scrub(label)
        if fieldname == 'name':
            continue
        new_doctype.append('fields', {
            'label': label,
            'fieldname': fieldname,
            'fieldtype': 'Data',
            'reqd': 0
        })

    try:
        new_doctype.insert(ignore_permissions=True)
        frappe.db.commit()
    except Exception as e:
        frappe.throw(f"Error creating DocType: {e}")

    return docname

@frappe.whitelist()
def sync_sheet_now(spreadsheet_name: str):
    """Trigger sync for a single SpreadSheet doctype record by name"""
    doc = frappe.get_doc('SpreadSheet', spreadsheet_name)
    # spreadsheet should have fields: sheet_url, mapped_doctype
    if not getattr(doc, 'sheet_url', None):
        frappe.throw('SpreadSheet has no sheet_url set')
    if not getattr(doc, 'mapped_doctype', None):
        frappe.throw('SpreadSheet has no mapped_doctype set')

    _import_csv_into_doctype(doc.sheet_url, doc.mapped_doctype)
    return True

def _import_csv_into_doctype(sheet_url, mapped_doctype):
    # convert to csv export
    csv_url = sheet_url
    if "/edit#gid=" in csv_url:
        csv_url = csv_url.replace("/edit#gid=", "/export?format=csv&gid=")
    elif csv_url.endswith("/edit"):
        csv_url = csv_url.replace("/edit", "/export?format=csv")

    res = requests.get(csv_url, timeout=20)
    res.raise_for_status()
    sio = StringIO(res.text)
    reader = csv.DictReader(sio)
    count = 0
    for row in reader:
        # create or update doc in mapped_doctype
        # simple insert: create new doc for each row
        new = frappe.new_doc(mapped_doctype)
        for k, v in row.items():
            if not k:
                continue
            fieldname = frappe.scrub(k)
            try:
                new.set(fieldname, v)
            except Exception:
                # ignore fields that don't exist
                pass
        new.insert(ignore_permissions=True)
        count += 1
    frappe.db.commit()
    frappe.msgprint(f"Imported {count} rows into {mapped_doctype}")
