import frappe
from .api import _import_csv_into_doctype

def sync_all_sheets():
    # find all SpreadSheet records with a mapped_doctype
    sheets = frappe.get_all('SpreadSheet', filters={'mapped_doctype': ['!=', '']}, fields=['name', 'sheet_url', 'mapped_doctype'])
    for s in sheets:
        try:
            _import_csv_into_doctype(s['sheet_url'], s['mapped_doctype'])
        except Exception as e:
            frappe.log_error(f"Error syncing sheet {s['name']}: {e}")
