app_name = "gsheet_auto_doctype"
app_title = "Google Sheet Auto Doctype"
app_publisher = "Generated"
app_description = "Auto-create DocType from Google Sheet header and sync"
app_icon = "octicon octicon-file-directory"
app_color = "grey"
app_email = "you@example.com"
app_license = "MIT"

app_include_js = "/assets/gsheet_auto_doctype/js/spreadsheet_buttons.js"

# Scheduler: run sync every 30 minutes
scheduler_events = {
    "cron": {
        "*/30 * * * *": [
            "gsheet_auto_doctype.scheduler.sync_all_sheets"
        ]
    }
}
