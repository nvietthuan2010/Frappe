frappe.ui.form.on('SpreadSheet', {
    refresh: function(frm) {
        // Only show buttons when doc saved
        if (frm.is_new()) return;

        frm.add_custom_button('Create DocType', function() {
            if (!frm.doc.sheet_url) {
                frappe.msgprint('Please add Sheet URL first');
                return;
            }
            frappe.call({
                method: 'gsheet_auto_doctype.api.create_doctype_from_sheet',
                args: {
                    sheet_url: frm.doc.sheet_url,
                    sheet_name: frm.doc.sheet_name || undefined
                },
                callback: function(r) {
                    if (r.message) {
                        frappe.msgprint('DocType created: ' + r.message);
                        frm.set_value('mapped_doctype', r.message);
                        frm.save();
                    }
                }
            });
        });

        frm.add_custom_button('Sync Now', function() {
            if (!frm.doc.sheet_url) {
                frappe.msgprint('Please add Sheet URL first');
                return;
            }
            if (!frm.doc.mapped_doctype) {
                frappe.msgprint('Please map a DocType first (or Create DocType)');
                return;
            }
            frappe.call({
                method: 'gsheet_auto_doctype.api.sync_sheet_now',
                args: { spreadsheet_name: frm.doc.name },
                callback: function(r) {
                    if (r.message) {
                        frappe.msgprint('Sync completed');
                    }
                }
            });
        });
    }
});
