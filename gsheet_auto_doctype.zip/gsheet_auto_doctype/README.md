gsheet_auto_doctype
===================

Minimal Frappe app for ERPNext/Frappe v15:
- Create a Custom DocType from the header row of a Google Sheet.
- Periodic sync (every 30 minutes) to import CSV rows into the mapped DocType.
- Adds buttons on the SpreadSheet form: Create DocType, Sync Now.

Installation:
    bench --site yoursite install-app /path/to/gsheet_auto_doctype.zip
    bench build
    bench restart

Notes:
- For private Google Sheets, extend the server-side fetch to use a Service Account.
