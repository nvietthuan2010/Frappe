from setuptools import setup, find_packages

setup(
    name="gsheet_auto_doctype",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    license="MIT",
    description="Auto-create DocType from Google Sheet and periodic sync (Frappe/ERPNext v15)",
    author="Generated",
    install_requires=[],
)
